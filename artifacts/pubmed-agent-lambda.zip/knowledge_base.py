# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import os
import re
import io
import time
import boto3
import requests
import datetime
import json
import xml.etree.ElementTree as xml

from botocore import UNSIGNED
from botocore.config import Config
from pymed import PubMed
from pymed.article import PubMedArticle
from pymed.book import PubMedBookArticle
from pymed.helpers import getContent
from langchain_core import documents
from connector.bm25 import bm25_retrieve
from typing import TypeVar, Iterator, Any
from util.custom_pubmed_article import CustomPubMedArticle
from util.tools import PubMedQueryGenerator

from connector import (
    Connector,
    ConnectorType,
    RewriteType,
    QueryInput,
    QueryOutput,
    Document,
    DocumentMetadata,
    logger,
)

OPEN_DATA_S3_BUCKET = "pmc-oa-opendata"

s3_client = boto3.client("s3", config=Config(signature_version=UNSIGNED))


def remove_text_after_last_match(text, pattern):
    matches = list(re.finditer(pattern, text))

    if matches:
        last_match = matches[-1]
        result = text[: last_match.start()]
    else:
        result = text

    return result


PRE_PROCESS_STEPS = [r"\n==== Refs\n", r"\nREFERENCES\n"]


def find_text_from_opendata(pmc_id):
    bucket = OPEN_DATA_S3_BUCKET

    providers = ["oa_comm", "oa_noncomm", "author_manuscript", "phe_timebound"]

    for provider in providers:
        key = f"{provider}/txt/all/{pmc_id}.txt"
        logger.info("Downloading OpenData file from:")
        logger.info(f"s3://{bucket}/{key}")
        try:
            with io.BytesIO() as buffer:
                s3_client.download_fileobj(bucket, key, buffer)
                buffer.seek(0)
                text = buffer.read().decode("utf-8")
                text = re.sub(r"\[[1-9]\d{0,3}\]", "", text)
                for step in PRE_PROCESS_STEPS:
                    new_text = remove_text_after_last_match(text, step)
                    if text != new_text:
                        text = new_text
                        break

                doc = documents.Document(page_content=text)
                doc.metadata["source"] = f"s3://{bucket}/{key}"
                return doc
        except Exception as e:
            if "HeadObject operation: Not Found" in str(e):
                continue
            else:
                raise


def get_pmc_article_from_pmc_id(pmc_id, abstract=None):
    default_source = f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmc_id}/"
    default_doc = documents.Document(
        page_content=abstract, metadata={"source": default_source}
    )
    if not pmc_id:
        return default_doc
    return find_text_from_opendata(pmc_id) or default_doc


def extract_pubmed_id(self: object, xml_element: TypeVar("Element")) -> str:  # type: ignore
    path = ".//PMID"
    return getContent(element=xml_element, path=path)


PubMedBookArticle._extractPubMedId = extract_pubmed_id
PubMedArticle._extractPubMedId = extract_pubmed_id


class CustomPubMed(PubMed):

    def __init__(
        self: object, tool: str = "my_tool", email: str = "my_email@example.com"
    ) -> None:
        """Initialization of the object.

        Parameters:
            - tool      String, name of the tool that is executing the query.
                        This parameter is not required but kindly requested by
                        PMC (PubMed Central).
            - email     String, email of the user of the tool. This parameter
                        is not required but kindly requested by PMC (PubMed Central).

        Returns:
            - None
        """

        # Store the input parameters
        self.tool = tool
        self.email = email

        # Keep track of the rate limit
        self._rateLimit = 3
        self._requestsMade = []

        # Define the standard / default query parameters
        self.parameters = {"tool": tool, "email": email, "db": "pubmed"}

    def query(self, query: str, ret_max: int = 20):
        """Method that executes a query agains the GraphQL schema, automatically
        inserting the PubMed data loader.

        Parameters:
            - query     String, the GraphQL query to execute against the schema.

        Returns:
            - result    ExecutionResult, GraphQL object that contains the result
                        in the "data" attribute.
        """
        for article_ids in self._get_article_ids(query=query, ret_max=ret_max):
            yield from self._getArticles(article_ids=article_ids)

    def get_response_from_pubmed(self, parameters):
        max_attempts = 2
        attempt = 0
        while attempt < max_attempts:
            try:
                response = self._get(
                    url="/entrez/eutils/esearch.fcgi", parameters=parameters
                )
                break
            except requests.exceptions.HTTPError as e:
                if attempt == max_attempts - 1:
                    raise e
                attempt += 1
                time.sleep(1)
        return response

    def _get_article_ids(self, query: str, ret_max: int = 10) -> Iterator[list[str]]:
        """Helper method to retrieve the article IDs for a query.

        Parameters:
            - query         Str, query to be executed against the PubMed database.

        Returns:
            - article_ids   List, article IDs as a list.
        """
        # Get the default parameters
        parameters: dict[str, Any] = self.parameters.copy()

        # Add specific query parameters
        parameters["term"] = query
        parameters["retmax"] = ret_max

        # Make the first request to PubMed
        response = self.get_response_from_pubmed(parameters)
        total_result_count = int(response.get("esearchresult", {}).get("count", 0))  # type: ignore
        retrieved_count = int(response.get("esearchresult", {}).get("retmax", 0))  # type: ignore

        while True:
            yield response.get("esearchresult", {}).get("idlist", [])  # type: ignore

            if retrieved_count >= total_result_count:
                break

            parameters["retstart"] = retrieved_count
            response = self.get_response_from_pubmed(parameters)
            retrieved_count += int(response.get("esearchresult", {}).get("retmax", 0))  # type: ignore

    def _getArticles(self: object, article_ids: list) -> list:
        """Helper method that batches a list of article IDs and retrieves the content.

        Parameters:
            - article_ids   List, article IDs.

        Returns:
            - articles      List, article objects.
        """

        # Get the default parameters
        parameters = self.parameters.copy()
        parameters["id"] = article_ids

        # Make the request
        response = self._get(
            url="/entrez/eutils/efetch.fcgi", parameters=parameters, output="xml"
        )

        # Parse as XML
        root = xml.fromstring(response)

        pubmed_articles = list(root.iter("PubmedArticle"))

        # Loop over the articles and construct article objects
        for article in pubmed_articles:
            yield CustomPubMedArticle(xml_element=article)


class PubMedConnector(Connector):
    name = "PubMed connector"
    description = "Search content in PubMed database"
    author = "Amazon Web Service"
    type = ConnectorType.KNOWLEDGE_BASE
    rewrite_type = RewriteType.ENGLISH_KEYWORD
    filter_config_path = "./util/connector_filter.json"
    with open(filter_config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
        connector_filters = config.get("filters", [])

    def __init__(self):
        self.pub_med = CustomPubMed(tool="PubMed")
        self.article_url = "https://www.ncbi.nlm.nih.gov/pmc/articles"
        self.pub_med.parameters["sort"] = "relevance"
        self.bm25_l2_norm_threshold = 0.2

        api_key = os.getenv("API_KEY")
        if api_key:
            self.pub_med.parameters["api_key"] = api_key

    def query(self, input: QueryInput) -> QueryOutput:
        output = QueryOutput(results=[])
        query_generator = PubMedQueryGenerator(self.filter_config_path)
        # Set sort parameter
        self.pub_med.parameters["sort"] = query_generator.get_sort_parameter(
            getattr(input, "connector_filters", [])
        )
        logger.info(f"Set sort to: {self.pub_med.parameters['sort']}")
        # Build advanced query
        advanced_query = query_generator.build_query(input)
        logger.info(f"Advanced query: {advanced_query}")
        try:
            articles = self.pub_med.query(
                query=advanced_query,
                ret_max=input.max_results,
            )

            for article in articles:
                logger.debug(f"Article: {article.toJSON()}")

                if (
                    article.title is None
                    or article.abstract is None
                    or article.pmc_id is None
                ):
                    continue
                text_content = get_pmc_article_from_pmc_id(
                    article.pmc_id, article.abstract
                )
                text_after_bm25 = bm25_retrieve(
                    input.rewritten_query, [text_content], top_k=3
                )

                # l2 norm score less than bm25_l2_norm_threshold will be trimmed
                trimed_text_after_bm25 = [
                    doc for doc in text_after_bm25 if doc.metadata["l2_score"] >= self.bm25_l2_norm_threshold
                ]

                resp_text = article.abstract
                for doc in trimed_text_after_bm25:
                    resp_text += doc.page_content + "\n"

                output.results.append(
                    Document(
                        title=article.title,
                        text=resp_text,
                        source=f"{self.article_url}/{article.pmc_id}",
                        metadata=DocumentMetadata(
                            release_date=(
                                article.publication_date.strftime("%Y-%m-%d")
                                if isinstance(article.publication_date, datetime.date)
                                else ""
                            )
                        ),
                    )
                )

                if len(output.results) >= input.max_results:
                    break
        except Exception as e:
            logger.error(e)

        return output


knowledge_base_connector = PubMedConnector()
