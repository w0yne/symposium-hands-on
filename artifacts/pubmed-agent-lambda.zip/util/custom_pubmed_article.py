# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import datetime

from typing import TypeVar
from pymed.helpers import getContent
from pymed.article import PubMedArticle


def get_first_content(element: TypeVar("Element"), path: str, default: str = None) -> str:
    """Internal helper method that retrieves the text content of the first matching
    XML element.

    Parameters:
        - element   Element, the XML element to parse.
        - path      Str, Nested path in the XML element.
        - default   Str, default value to return when no text is found.

    Returns:
        - text      Str, text in the first matching XML node or default if not found.
    """
    # Find the first matching element
    result = element.find(path)

    # Return the default if there is no such element
    if result is None or result.text is None:
        return default

    # Return the text content
    return result.text


class CustomPubMedArticle(PubMedArticle):
    """Data class that contains a PubMed article."""

    __slots__ = (
        "pubmed_id",
        "pmc_id",
        "title",
        "abstract",
        "keywords",
        "journal",
        "publication_date",
        "authors",
        "methods",
        "conclusions",
        "results",
        "copyrights",
        "doi",
        "xml",
    )

    def _extractPMCId(self: object, xml_element: TypeVar("Element")) -> str:
        path = ".//ArticleId[@IdType='pmc']"
        return get_first_content(element=xml_element, path=path)

    def _initializeFromXML(self: object, xml_element: TypeVar("Element")) -> None:
        """Helper method that parses an XML element into an article object."""

        # Parse the different fields of the article
        self.pubmed_id = self._extractPubMedId(xml_element)
        self.pmc_id = self._extractPMCId(xml_element)
        self.title = self._extractTitle(xml_element)
        self.keywords = self._extractKeywords(xml_element)
        self.journal = self._extractJournal(xml_element)
        self.abstract = self._extractAbstract(xml_element)
        self.conclusions = self._extractConclusions(xml_element)
        self.methods = self._extractMethods(xml_element)
        self.results = self._extractResults(xml_element)
        self.copyrights = self._extractCopyrights(xml_element)
        self.doi = self._extractDoi(xml_element)
        self.publication_date = self._extractPublicationDate(xml_element)
        self.authors = self._extractAuthors(xml_element)
        self.xml = xml_element
