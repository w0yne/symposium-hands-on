import json
import boto3
import time
import os
import uuid
import logging
from botocore.exceptions import ClientError
from datetime import datetime

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize Bedrock Agent client
bedrock_agent = boto3.client('bedrock-agent')
iam = boto3.client('iam')
sts = boto3.client('sts')

# Custom JSON encoder to handle datetime objects
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)

def json_dumps(obj):
    """Helper function to serialize objects to JSON with datetime handling"""
    return json.dumps(obj, cls=DateTimeEncoder)

def get_aws_account_id():
    """Get current AWS account ID"""
    try:
        response = sts.get_caller_identity()
        return response['Account']
    except Exception as e:
        logger.error(f"Error retrieving AWS account ID: {str(e)}")
        raise

def create_service_role():
    """Create a new IAM role for the Bedrock agent with proper permissions using inline policy"""
    role_name = f"BedrockAgentRole-{str(uuid.uuid4())[:8]}"
    
    # Get AWS account ID for the policy
    account_id = get_aws_account_id()
    
    # Define the trust policy for Bedrock to assume this role
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": "bedrock.amazonaws.com"
                },
                "Action": "sts:AssumeRole"
            }
        ]
    }
    
    # Define the permissions policy with dynamic account ID
    inline_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "AmazonBedrockAgentInferenceProfilesCrossRegionPolicyProd",
                "Effect": "Allow",
                "Action": [
                    "bedrock:InvokeModel",
                    "bedrock:InvokeModelWithResponseStream",
                    "bedrock:GetInferenceProfile",
                    "bedrock:GetFoundationModel"
                ],
                "Resource": [
                    f"arn:aws:bedrock:us-east-1:{account_id}:inference-profile/us.deepseek.r1-v1:0",
                    "arn:aws:bedrock:*::foundation-model/deepseek.r1-v1:0"
                ]
            }
        ]
    }
    
    try:
        # Create the role with the inline policy
        role_response = iam.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=json.dumps(trust_policy),
            Description="IAM role for Bedrock agent Medical-Writing-Expert"
        )
        
        role_arn = role_response['Role']['Arn']
        logger.info(f"Created IAM role: {role_arn}")
        
        # Attach the inline policy to the role
        iam.put_role_policy(
            RoleName=role_name,
            PolicyName="BedrockAgentInlinePolicy",
            PolicyDocument=json.dumps(inline_policy)
        )
        
        logger.info(f"Attached inline policy to role {role_name}")
        
        # Wait for the role to be available
        logger.info(f"Waiting for role {role_name} to be available")
        time.sleep(10)  # Allow time for IAM role to propagate
        
        return role_arn
    
    except ClientError as e:
        logger.error(f"Error creating IAM role: {str(e)}")
        raise

def wait_for_agent_status(agent_id, target_status='PREPARED', fail_states=None):
    """
    Wait for the agent to reach the specified status
    
    Args:
        agent_id (str): The agent ID to check
        target_status (str or list): Status or list of statuses to wait for
        fail_states (list, optional): List of states that indicate failure
    
    Returns:
        bool: True if reached target status, False if failed
    """
    max_attempts = 30
    attempts = 0
    
    # Convert single status to list for consistent handling
    if isinstance(target_status, str):
        target_statuses = [target_status]
    else:
        target_statuses = target_status
        
    # Default fail states
    if fail_states is None:
        fail_states = ['FAILED', 'CREATION_FAILED', 'PREPARATION_FAILED']
    
    logger.info(f"Waiting for agent {agent_id} to reach one of these statuses: {target_statuses}")
    
    while attempts < max_attempts:
        try:
            response = bedrock_agent.get_agent(agentId=agent_id)
            logger.info(f"Get agent response: {json_dumps(response)}")
            
            # Handle nested response structure
            if 'agent' in response and isinstance(response['agent'], dict):
                agent_data = response['agent']
                if 'agentStatus' in agent_data:
                    current_status = agent_data['agentStatus']
                elif 'status' in agent_data:
                    current_status = agent_data['status']
                else:
                    logger.warning(f"Could not find status in nested agent data")
                    current_status = "UNKNOWN"
            # Fall back to top-level response fields
            elif 'agentStatus' in response:
                current_status = response['agentStatus']
            elif 'status' in response:
                current_status = response['status']
            else:
                logger.warning(f"Could not find status in response")
                current_status = "UNKNOWN"
                
            logger.info(f"Agent status: {current_status}")
            
            # Check if we've reached a target status
            if current_status in target_statuses:
                logger.info(f"Agent reached target status: {current_status}")
                return True
            
            # Check if we've hit a failure state
            if current_status in fail_states:
                logger.error(f"Agent creation failed with status: {current_status}")
                return False
            
            attempts += 1
            time.sleep(10)  # Wait 10 seconds before checking again
        except Exception as e:
            logger.error(f"Error checking agent status: {str(e)}")
            attempts += 1
            time.sleep(10)
    
    logger.error(f"Timed out waiting for agent to reach status {target_statuses}")
    return False

def lambda_handler(event, context):
    try:
        logger.info(f"Starting agent creation process - event: {json_dumps(event)}")
        
        # Get AWS account ID for the foundation model ARN
        account_id = get_aws_account_id()
        foundation_model_arn = f"arn:aws:bedrock:us-east-1:{account_id}:inference-profile/us.deepseek.r1-v1:0"
        logger.info(f"Using foundation model ARN: {foundation_model_arn}")
        
        # Step 1: Create a service role for the agent
        role_arn = create_service_role()
        logger.info(f"Created service role: {role_arn}")
        
        # Step 2: Create the agent
        response = bedrock_agent.create_agent(
            agentName="Medical-Writing-Expert",
            agentResourceRoleArn=role_arn,
            foundationModel=foundation_model_arn,
            description="医学写作大纲助手",
            instruction="你是一个专业的医学写作助手，可以根据用户的输入生成有条理的三条大纲，回复的内容请仅包含标题。",
            clientToken=str(uuid.uuid4())
        )
        
        # Log the full response for debugging (using custom JSON encoder)
        logger.info(f"Create agent response: {json_dumps(response)}")
        
        # Check if the response has an 'agent' key (nested structure)
        if 'agent' in response and isinstance(response['agent'], dict):
            agent_data = response['agent']
            if 'agentId' in agent_data:
                agent_id = agent_data['agentId']
            elif 'id' in agent_data:
                agent_id = agent_data['id']
            elif 'agentArn' in agent_data:
                agent_id = agent_data['agentArn'].split('/')[-1]
            else:
                raise ValueError(f"Could not find agent ID in nested agent data")
        # Fall back to checking top-level response (older API versions)
        elif 'agentId' in response:
            agent_id = response['agentId']
        elif 'id' in response:
            agent_id = response['id']
        elif 'agentArn' in response:
            agent_id = response['agentArn'].split('/')[-1]
        else:
            raise ValueError(f"Could not find agent ID in response")
                
        logger.info(f"Created agent with ID: {agent_id}")
        
        # Step 3: Wait for the agent to be in NOT_PREPARED state (ready to be prepared)
        if not wait_for_agent_status(agent_id, 'NOT_PREPARED'):
            return {
                'statusCode': 500,
                'body': json.dumps('Failed to create agent')
            }
        
        # Step 4: Prepare the agent
        prepare_response = bedrock_agent.prepare_agent(
            agentId=agent_id
        )
        logger.info(f"Prepare agent initiated: {json_dumps(prepare_response)}")
        
        # Step 5: Wait for the agent to be prepared
        if not wait_for_agent_status(agent_id, 'PREPARED'):
            return {
                'statusCode': 500,
                'body': json.dumps('Failed to prepare agent')
            }
        
        # Step 6: Create an alias for the agent
        alias_response = bedrock_agent.create_agent_alias(
            agentId=agent_id,
            agentAliasName="Collaborator-Writing-Expert",
            description="Alias for Medical Writing Expert"
        )
        
        logger.info(f"Created alias: {json_dumps(alias_response)}")
        
        # Extract the agent alias ID from the response
        agent_alias_id = 'Unknown'
        if 'agentAlias' in alias_response and isinstance(alias_response['agentAlias'], dict):
            agent_alias_id = alias_response['agentAlias'].get('agentAliasId', 'Unknown')
        else:
            agent_alias_id = alias_response.get('agentAliasId', 'Unknown')
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'agentId': agent_id,
                'agentAliasId': agent_alias_id,
                'message': 'Successfully created Bedrock agent and alias'
            })
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error creating Bedrock agent: {str(e)}')
        }