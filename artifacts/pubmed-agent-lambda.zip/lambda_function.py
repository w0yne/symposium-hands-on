import json
from knowledge_base import knowledge_base_connector
from connector import QueryInput, logger

def lambda_handler(event, context):
    params_dict = {"request_type": "query"}
    logger.info("Event: %s", json.dumps(event))
    # 从新的事件格式中提取参数
    if 'parameters' in event and isinstance(event['parameters'], list):
        for param in event['parameters']:
            name = param.get('name')
            value = param.get('value')
            param_type = param.get('type')
            
            if name and value is not None:
                # 根据类型转换值
                if param_type == 'integer':
                    try:
                        params_dict[name] = int(value)
                    except (ValueError, TypeError):
                        params_dict[name] = 0  # 默认值
                elif param_type == 'array':
                    try:
                        # 尝试解析JSON字符串
                        parsed_value = json.loads(value)
                        # 如果是 null 或空对象，设置为空数组
                        if parsed_value is None or (isinstance(parsed_value, list) and len(parsed_value) == 1 and parsed_value[0] == {}):
                            params_dict[name] = []
                        else:
                            params_dict[name] = parsed_value
                    except:
                        params_dict[name] = []
                else:
                    params_dict[name] = value
    
    # 确保必要的参数存在
    if 'query' not in params_dict:
        # 如果没有找到查询参数，尝试从 inputText 获取
        if 'inputText' in event:
            params_dict['query'] = event['inputText']
        else:
            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup"),
                    "function": event.get("function"),
                    "functionResponse": {
                        "responseState": "FAILURE",
                        "responseBody": {
                            "text/plain": {
                                "body": json.dumps({
                                    "error": "No query parameter found"
                                })
                            }
                        }
                    }
                }
            }
    
    if 'max_results' not in params_dict:
        params_dict['max_results'] = 3  # 默认值
        
    # 确保 connector_filters 是一个数组
    if 'connector_filters' not in params_dict or params_dict['connector_filters'] is None:
        params_dict['connector_filters'] = []
    
    try:
        # 执行您的搜索逻辑...
        logger.info("params_dict: %s", json.dumps(params_dict))

        # 使用QueryInput处理参数并获取结果
        results = knowledge_base_connector.query(input=QueryInput(**params_dict)).model_dump()
        print("Result structure:", results)  # 添加这行来查看结构

        # 将结果转换为JSON字符串
        results_json = json.dumps(results)

        # 构建成功返回格式
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup"),
                "function": event.get("function"),
                "functionResponse": {
                    "responseBody": {
                        "TEXT": {
                            "body": results_json
                        }
                    }
                }
            },
            # 保留原始会话属性（如果存在）
            "sessionAttributes": event.get("sessionAttributes", {}),
            "promptSessionAttributes": event.get("promptSessionAttributes", {})
        }
    except Exception as e:
        # 处理错误情况
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup"),
                "function": event.get("function"),
                "functionResponse": {
                    "responseState": "FAILURE",
                    "responseBody": {
                        "TEXT": {
                            "body": json.dumps({
                                "error": str(e)
                            })
                        }
                    }
                }
            },
            "sessionAttributes": event.get("sessionAttributes", {}),
            "promptSessionAttributes": event.get("promptSessionAttributes", {})
        }
