# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
from typing import Dict, Any, Tuple
from datetime import datetime
from connector import QueryInput
from collections import defaultdict
import json


class PubMedQueryGenerator:
    def __init__(self, filter_config_path: str):
        """Initialize with filter configuration file path"""
        with open(filter_config_path, "r", encoding="utf-8") as f:
            self.filter_config = json.load(f)

    def _get_filter_config(self, field_name: str) -> Dict[str, Any]:
        """Get filter configuration by field name"""
        for filter_config in self.filter_config["filters"]:
            if filter_config["field_name"] == field_name:
                return filter_config
        return None

    def _process_date_range(self, value: str) -> Tuple[str, str]:
        """Process date range value from timestamps to PubMed format"""
        timestamps = value.strip("[]").split(",")
        if len(timestamps) != 2:
            raise ValueError("Invalid date range format")

        start_date = datetime.fromtimestamp(int(timestamps[0])).strftime("%Y/%m/%d")
        end_date = datetime.fromtimestamp(int(timestamps[1])).strftime("%Y/%m/%d")

        return start_date, end_date

    def _build_filter_query(self, filter_item: Dict[str, Any]) -> str:
        """Build a single filter query"""
        field_name = filter_item["field_name"]
        value = filter_item["value"]

        filter_config = self._get_filter_config(field_name)
        if not filter_config:
            return f"({value})"

        filter_type = filter_config["type"]
        display_name = filter_config["display_name"]

        if filter_type == "DATE_RANGE":
            start_date, end_date = self._process_date_range(value)
            return f'("{start_date}"[{display_name}] : "{end_date}"[{display_name}])'

        elif filter_type == "STRING":
            if field_name in ["custom_query", "all_fields"]:
                return f"({value})"

            if field_name == "sort":
                return ""

            return f"({value}[{display_name}])"

        return f"({value})"

    def build_query(self, input: QueryInput) -> str:
        """Build the query string for PubMed API
        PubMed Advanced Search Webpage: https://pubmed.ncbi.nlm.nih.gov/advanced/
        The operator of each filter will be EQUAL or NOT.
        Parameters:
        - input: QueryInput object
            {
                "connector_filters": [
                    {
                        "field_name": "author",
                        "value": "John Smith",
                        "operator": "EQUAL"
                    },
                    {
                        "field_name": "author",
                        "value": "Magic Hu",
                        "operator": "EQUAL"
                    },
                    {
                        "field_name": "publication_date",
                        "value": "[1577836800,1609459200]",
                        "operator": "EQUAL"
                    },
                    {
                        "field_name": "journal",
                        "value": "Nature",
                        "operator": "AND"
                    },
                    {
                        "field_name": "language",
                        "value": "English",
                        "operator": "NOT"
                    },
                    {
                        "field_name": "title",
                        "value": "CRISPR"
                    },
                    {
                        "field_name": "sort",
                        "value": "pub_date"
                    }
                ]
            }
        """
        query_parts = []
        base_query = getattr(input, "rewritten_query", None) or getattr(
            input, "query", None
        )
        if base_query:
            query_parts.append(f"({base_query})")
        connector_filters = getattr(input, "connector_filters", []) or []
        # Add default filter for open access articles
        default_filter = {
            "field_name": "filter",
            "value": "pubmed pmc open access",
            "operator": "EQUAL",
        }
        connector_filters.append(default_filter)

        # Create a nested defaultdict to group filters by field_name and operator
        field_groups = defaultdict(lambda: defaultdict(list))

        # Group filters by field_name and operator
        for filter_item in connector_filters:
            if filter_item["field_name"] != "sort":  # Skip sort filters
                field_name = filter_item["field_name"]
                operator = filter_item.get("operator", "EQUAL")
                field_groups[field_name][operator].append(filter_item)

        # Process grouped filters
        for field_name, operators in field_groups.items():
            # Process EQUAL filters
            equal_queries = [
                self._build_filter_query(filter_item)
                for filter_item in operators["EQUAL"]
                if self._build_filter_query(filter_item)
            ]

            if equal_queries:
                # Combine multiple EQUAL filters with OR
                combined_query = (
                    f"({' OR '.join(equal_queries)})"
                    if len(equal_queries) > 1
                    else equal_queries[0]
                )

                if query_parts:
                    query_parts.append("AND")
                query_parts.append(combined_query)

            # Process NOT filters
            for not_filter in operators["NOT"]:
                filter_query = self._build_filter_query(not_filter)
                query_parts.append("NOT")
                query_parts.append(filter_query)

        # Return empty string if no parts
        if not query_parts:
            return ""

        # Return single part directly
        if len(query_parts) == 1:
            return query_parts[0]

        # Join all parts with spaces and wrap in parentheses
        return f"{' '.join(query_parts)}"

    def get_sort_parameter(self, connector_filters: list) -> str:
        """Extract the first sort filter value from connector_filters"""
        for filter_item in connector_filters:
            if filter_item["field_name"] == "sort":
                return filter_item["value"]
        return "relevance"
