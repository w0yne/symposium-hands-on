# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import time
from pathlib import Path
from typing import List

import os
import numpy as np
from langchain_community.retrievers import BM25Retriever
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from tokenizers import Tokenizer
from connector.logger import logger

os.environ["HF_HOME"] = "/tmp/"
TOKENIZER_JSON_FILE = Path(__file__).parent.parent / "connector" / "tokenizer.json"

tokenizer = Tokenizer.from_file(TOKENIZER_JSON_FILE.as_posix())
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=512,
    chunk_overlap=50,
    length_function=len,
    is_separator_regex=False,
)


def preprocess_func_fast(text: str) -> List[str]:
    if not text:
        return []
    tokens = tokenizer.encode(text, add_special_tokens=False).tokens
    # Stringify the tokens
    return [str(token) for token in tokens]


class BM25RetrieverWithScore(BM25Retriever):
    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        L2_MAX_RETRIEVAL_K = 50
        processed_query = self.preprocess_func(query)

        assert self.vectorizer.corpus_size == len(
            self.docs
        ), "The documents given don't match the index corpus!"
        scores = self.vectorizer.get_scores(processed_query)

        effective_k = min(L2_MAX_RETRIEVAL_K, len(self.docs))
        top_n = np.argsort(scores)[::-1][:effective_k]

        top_scores = scores[top_n]
        l2_norm = np.sqrt(np.sum(np.square(top_scores)))

        if l2_norm > 0:
            normalized_scores = top_scores / l2_norm
        else:
            normalized_scores = np.zeros_like(top_scores)

        # only return the top k documents which customer wants
        ret = []
        for i in range(min(self.k, len(top_n))):
            doc = self.docs[top_n[i]].copy(deep=True)
            doc.metadata["score"] = scores[top_n[i]]
            doc.metadata["l2_score"] = normalized_scores[i]
            ret.append(doc)
        return ret


def bm25_retrieve(
    query: str, documents: list[Document], top_k=5, preprocess_func=preprocess_func_fast
) -> list[Document]:
    """Retrieve the top k documents from the given list of documents using BM25."""
    text_chunks: list[Document] = text_splitter.split_documents(documents)
    logger.debug(f"text_chunks: {text_chunks}")

    valid_chunks = [doc for doc in text_chunks if doc.page_content]
    if not valid_chunks:
        logger.warning(
            "No valid documents available for BM25 retrieval. Returning empty list."
        )
        return []

    start_time = time.time()
    retriever = BM25RetrieverWithScore.from_documents(
        valid_chunks, preprocess_func=preprocess_func
    )
    end_time = time.time()
    logger.info(f"BM25 retrieval took {end_time - start_time:.2f} seconds")

    return retriever.invoke(query, top_k=top_k)
