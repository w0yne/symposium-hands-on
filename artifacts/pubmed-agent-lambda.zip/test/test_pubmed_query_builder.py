# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import pytest
from typing import Dict, List
import json
from util.tools import PubMedQueryGenerator


class MockQueryInput:
    def __init__(
        self,
        query: str = None,
        rewritten_query: str = None,
        connector_filters: List[Dict] = None,
    ):
        self.query = query
        self.rewritten_query = rewritten_query
        self.connector_filters = connector_filters or []


@pytest.fixture
def filter_config():
    return {
        "filters": [
            {"field_name": "author", "display_name": "Author", "type": "STRING"},
            {"field_name": "journal", "display_name": "Journal", "type": "STRING"},
            {
                "field_name": "publication_date",
                "display_name": "Date - Publication",
                "type": "DATE_RANGE",
            },
            {"field_name": "language", "display_name": "Language", "type": "STRING"},
            {"field_name": "title", "display_name": "Title", "type": "STRING"},
        ]
    }


@pytest.fixture
def config_file(filter_config, tmp_path):
    """Create a temporary config file for testing"""
    config_file = tmp_path / "test_config.json"
    config_file.write_text(json.dumps(filter_config))
    return str(config_file)


@pytest.fixture
def query_generator(config_file):
    """Create a PubMedQueryGenerator instance for testing"""
    return PubMedQueryGenerator(config_file)


def test_basic_query(query_generator):
    """Test basic query without filters"""
    input_query = MockQueryInput(query="cancer")
    result = query_generator.build_query(input_query)
    assert result == "(cancer) AND (pubmed pmc open access)"


def test_rewritten_query_precedence(query_generator):
    """Test that rewritten_query takes precedence over query"""
    input_query = MockQueryInput(query="cancer", rewritten_query="advanced cancer")
    result = query_generator.build_query(input_query)
    assert result == "(advanced cancer) AND (pubmed pmc open access)"


def test_multiple_equal_authors(query_generator):
    """Test multiple EQUAL filters for the same field (author)"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {"field_name": "author", "value": "Smith", "operator": "EQUAL"},
            {"field_name": "author", "value": "Johnson", "operator": "EQUAL"},
        ],
    )
    result = query_generator.build_query(input_query)
    assert (
        result
        == "(cancer) AND ((Smith[Author]) OR (Johnson[Author])) AND (pubmed pmc open access)"
    )


def test_date_range_filter(query_generator):
    """Test date range filter"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {
                "field_name": "publication_date",
                "value": "[1577836800,1609459200]",
                "operator": "EQUAL",
            }
        ],
    )
    result = query_generator.build_query(input_query)
    print(f"result: {result}")
    assert (
        result
        == '(cancer) AND ("2020/01/01"[Date - Publication] : "2021/01/01"[Date - Publication]) AND (pubmed pmc open access)'
    )


def test_not_operator(query_generator):
    """Test NOT operator"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {"field_name": "language", "value": "Chinese", "operator": "NOT"}
        ],
    )
    result = query_generator.build_query(input_query)
    assert result == "(cancer) NOT (Chinese[Language]) AND (pubmed pmc open access)"


def test_complex_query(query_generator):
    """Test complex query with multiple operators and fields"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {"field_name": "author", "value": "Smith", "operator": "EQUAL"},
            {"field_name": "author", "value": "Johnson", "operator": "EQUAL"},
            {"field_name": "journal", "value": "Nature", "operator": "EQUAL"},
            {"field_name": "language", "value": "Chinese", "operator": "NOT"},
        ],
    )
    result = query_generator.build_query(input_query)
    expected = "(cancer) AND ((Smith[Author]) OR (Johnson[Author])) AND (Nature[Journal]) NOT (Chinese[Language]) AND (pubmed pmc open access)"
    assert result == expected


def test_ignore_sort_filter(query_generator):
    """Test that sort filters are ignored"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {"field_name": "sort", "value": "pub_date"},
            {"field_name": "author", "value": "Smith", "operator": "EQUAL"},
        ],
    )
    result = query_generator.build_query(input_query)
    assert result == "(cancer) AND (Smith[Author]) AND (pubmed pmc open access)"


def test_empty_filters(query_generator):
    """Test empty filters list"""
    input_query = MockQueryInput(query="cancer", connector_filters=[])
    result = query_generator.build_query(input_query)
    assert result == "(cancer) AND (pubmed pmc open access)"


def test_default_equal_operator(query_generator):
    """Test default EQUAL operator when operator is not specified"""
    input_query = MockQueryInput(
        query="cancer", connector_filters=[{"field_name": "author", "value": "Smith"}]
    )
    result = query_generator.build_query(input_query)
    assert result == "(cancer) AND (Smith[Author]) AND (pubmed pmc open access)"


def test_complex_query_2(query_generator):
    """Test complex query with multiple operators and fields"""
    input_query = MockQueryInput(
        query="cancer",
        connector_filters=[
            {"field_name": "author", "value": "Smith", "operator": "EQUAL"},
            {"field_name": "author", "value": "Johnson", "operator": "EQUAL"},
            {"field_name": "author", "value": "James", "operator": "NOT"},
            {"field_name": "author", "value": "Kevin", "operator": "NOT"},
        ],
    )
    result = query_generator.build_query(input_query)
    print(f"result: {result}")
    expected = "(cancer) AND ((Smith[Author]) OR (Johnson[Author])) NOT (James[Author]) NOT (Kevin[Author]) AND (pubmed pmc open access)"
    assert result == expected