# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
from connector.model import (
    Input,
    Output,
    MetadataInput,
    MetadataOutput,
    QueryInput,
    QueryOutput,
    Document,
    DocumentMetadata,
)
from connector.enum import ConnectorType, RewriteType, RequestType
from connector.logger import logger


class Connector:
    name = "Knowledge Base connector"
    description = "Knowledge Base connector"
    author = "Amazon Web Service"
    type = ConnectorType.KNOWLEDGE_BASE
    rewrite_type = RewriteType.NONE
    connector_filters = []

    @property
    def metadata(self) -> MetadataOutput:
        return MetadataOutput(
            name=self.name,
            description=self.description,
            type=self.type,
            author=self.author,
            rewrite_type=self.rewrite_type,
            connector_filters=self.connector_filters,
        )

    def query(self, input: QueryInput) -> QueryOutput:
        return QueryOutput(results=[])
