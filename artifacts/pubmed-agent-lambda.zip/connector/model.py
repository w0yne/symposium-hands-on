# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
from typing import Optional, List
from pydantic import BaseModel, SerializeAsAny
from connector.enum import RequestType, RewriteType


class Input(BaseModel):
    request_type: RequestType


class Output(BaseModel):
    pass


class MetadataInput(Input):
    pass


class MetadataOutput(Output):
    name: str
    description: Optional[str] = None
    type: str
    author: str
    rewrite_type: Optional[RewriteType] = RewriteType.NONE
    connector_filters: Optional[List[object]] = None


class QueryInput(Input):
    query: str
    rewritten_query: Optional[str] = None
    connector_filters: Optional[List[object]] = None
    max_results: int = 10


class DocumentMetadata(BaseModel):
    release_date: Optional[str] = None


class Document(BaseModel):
    title: str
    text: str
    score: Optional[float] = None
    source: str
    metadata: Optional[SerializeAsAny[DocumentMetadata]] = None


class QueryOutput(Output):
    results: list[Document]
