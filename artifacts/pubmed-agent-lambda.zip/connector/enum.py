# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
from enum import Enum


class CommonEnum(str, Enum):
    def __str__(self) -> str:
        return self.value

    def __repr__(self) -> str:
        return self.value


class RequestType(CommonEnum):
    METADATA = "metadata"
    QUERY = "query"


class RewriteType(CommonEnum):
    ENGLISH_KEYWORD = "english_keyword"
    NONE = None


class ConnectorType(CommonEnum):
    KNOWLEDGE_BASE = "knowledge_base"
    SEARCH_ENGINE = "search_engine"
    